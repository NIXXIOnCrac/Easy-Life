"""Test the Pro license system end-to-end against a fake activation endpoint."""
import json
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

import pytest
from starlette.testclient import TestClient

from pcrituals.api import create_app
from pcrituals.config import load_config


class FakeActivate(BaseHTTPRequestHandler):
    def do_GET(self):
        code = self.path.split("code=", 1)[-1] if "code=" in self.path else ""
        if code == "EASY-GOOD-1234":
            body = json.dumps({"valid": True, "plan": "pro", "valid_until": time.time() + 30 * 24 * 3600}).encode()
            self.send_response(200)
        else:
            body = json.dumps({"valid": False, "message": "Unknown license code."}).encode()
            self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *a):  # silence
        pass


@pytest.fixture
def fake_server():
    srv = HTTPServer(("127.0.0.1", 0), FakeActivate)
    port = srv.server_address[1]
    t = threading.Thread(target=srv.serve_forever, daemon=True)
    t.start()
    yield f"http://127.0.0.1:{port}/api/activate"
    srv.shutdown()


@pytest.fixture
def client(tmp_path, fake_server, monkeypatch):
    monkeypatch.setenv("PCRITUALS_DATA_DIR", str(tmp_path))
    monkeypatch.setenv("PCRITUALS_LICENSE_URL", fake_server)
    monkeypatch.delenv("PCRITUALS_TLS", raising=False)
    app = create_app()
    c = TestClient(app)
    c.post("/api/auth/setup", json={"username": "t", "password": "pass1234"})
    tok = c.post("/api/auth/login", json={"username": "t", "password": "pass1234"}).json()["token"]
    c.headers.update({"Authorization": f"Bearer {tok}"})
    return c


def test_starts_free(client):
    s = client.get("/api/pro/status").json()
    assert s["is_pro"] is False
    assert s["plan"] == "free"


def test_bad_code_rejected(client):
    r = client.post("/api/pro/activate", json={"code": "EASY-BAD-9999"})
    assert r.status_code == 400
    assert client.get("/api/pro/status").json()["is_pro"] is False


def test_good_code_activates(client):
    r = client.post("/api/pro/activate", json={"code": "EASY-GOOD-1234"})
    assert r.status_code == 200
    s = r.json()
    assert s["is_pro"] is True
    assert s["plan"] == "pro"
    # persisted
    assert client.get("/api/pro/status").json()["is_pro"] is True


def test_empty_code_rejected(client):
    r = client.post("/api/pro/activate", json={"code": ""})
    assert r.status_code == 400
