"""Easy Life Pro license validation.

The app stays local-first: it never requires a cloud account to run. Pro is an
optional unlock. The user pastes a license code (bought on the website) into
Settings -> Pro; this module validates that code against the website's
activation endpoint and caches the result locally so the app works offline
between checks.

Design rules:
  * The app never stores the user's website password or account — only the
    license code they chose to paste.
  * Validation is a single HTTPS GET to the activation endpoint. On failure
    (offline, site down) the app keeps the last known-good state rather than
    bricking Pro for a network blip.
  * The code is stored in settings.json alongside the other runtime settings.
"""

from __future__ import annotations

import json
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path

# How long a successful validation is trusted before re-checking. A day is a
# good balance: a lapsed subscription stops working within a day, but the app
# still works offline in between.
CACHE_TTL = 24 * 60 * 60

# Default activation endpoint. The website's /api/activate.js answers it.
DEFAULT_ACTIVATE_URL = "https://easy-life-website.vercel.app/api/activate"


class LicenseError(RuntimeError):
    """Raised when a license code is rejected or the endpoint is unreachable."""


@dataclass
class LicenseState:
    code: str = ""
    plan: str = "free"          # "free" or "pro"
    valid_until: float = 0.0    # epoch seconds; 0 = not validated
    checked_at: float = 0.0     # epoch seconds of the last successful check
    error: str = ""

    @property
    def is_pro(self) -> bool:
        if self.plan != "pro":
            return False
        if self.valid_until and self.valid_until < time.time():
            return False
        return True

    @property
    def needs_recheck(self) -> bool:
        return not self.checked_at or (time.time() - self.checked_at) > CACHE_TTL


def _load(path: Path) -> LicenseState:
    try:
        d = json.loads(path.read_text())
        return LicenseState(
            code=str(d.get("code", "")),
            plan=str(d.get("plan", "free")),
            valid_until=float(d.get("valid_until", 0.0)),
            checked_at=float(d.get("checked_at", 0.0)),
            error=str(d.get("error", "")),
        )
    except Exception:
        return LicenseState()


def _save(path: Path, st: LicenseState) -> None:
    path.write_text(json.dumps({
        "code": st.code,
        "plan": st.plan,
        "valid_until": st.valid_until,
        "checked_at": st.checked_at,
        "error": st.error,
    }, indent=2))


class License:
    """Validates and caches a Pro license code."""

    def __init__(self, data_dir: Path, activate_url: str = DEFAULT_ACTIVATE_URL,
                 timeout: float = 10.0) -> None:
        self._file = data_dir / "license.json"
        self._url = (activate_url or DEFAULT_ACTIVATE_URL).rstrip("/")
        self._timeout = timeout

    def status(self) -> dict:
        st = _load(self._file)
        return {
            "code": st.code,
            "plan": st.plan,
            "is_pro": st.is_pro,
            "valid_until": st.valid_until,
            "checked_at": st.checked_at,
            "error": st.error,
            "needs_recheck": st.needs_recheck,
        }

    def activate(self, code: str) -> dict:
        """Validate a code against the site and, if good, cache it as Pro."""
        code = (code or "").strip()
        if not code:
            raise LicenseError("Enter your license code first.")
        try:
            result = self._check(code)
        except LicenseError:
            raise
        except Exception as e:  # network / parse
            raise LicenseError(f"Couldn't reach the license server: {e}") from e

        if not result.get("valid"):
            raise LicenseError(result.get("message") or "That license code isn't valid.")

        st = LicenseState(
            code=code,
            plan=str(result.get("plan", "pro")),
            valid_until=float(result.get("valid_until", 0.0)),
            checked_at=time.time(),
        )
        _save(self._file, st)
        return self.status()

    def refresh(self) -> dict:
        """Re-check the stored code (e.g. on startup). Keeps last-good on failure."""
        st = _load(self._file)
        if not st.code:
            return self.status()
        try:
            result = self._check(st.code)
        except Exception:
            # Offline or site down: keep the cached state, don't brick Pro.
            return self.status()
        if result.get("valid"):
            st.plan = str(result.get("plan", "pro"))
            st.valid_until = float(result.get("valid_until", 0.0))
            st.checked_at = time.time()
            st.error = ""
        else:
            st.plan = "free"
            st.error = result.get("message") or "License no longer valid."
        _save(self._file, st)
        return self.status()

    def _check(self, code: str) -> dict:
        url = f"{self._url}?code={urllib.parse.quote(code)}"
        req = urllib.request.Request(url, headers={"Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=self._timeout) as resp:
            body = resp.read().decode("utf-8", "replace")
        return json.loads(body)
