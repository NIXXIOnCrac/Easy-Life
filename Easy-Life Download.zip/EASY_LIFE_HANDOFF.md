# EASY LIFE — FULL PROJECT HANDOFF
**For the next agent. Read this entire file before touching anything.**
Generated: 2026-09-18 · Repo: `/opt/data/pc-rituals` (branch `master`) · App version `0.1.0`

> **UPDATE (final handoff):** Since the first version of this file, the Pro gate
> was wired and verified (commit `c9b9dd1`). See §5 and §6. Test count is now
> **587 backend + 5 frontend suites pass**, tree clean, ZIP rebuilt (v15, 129
> files). The one remaining product decision — what else Pro unlocks — is still
> open; sync is now the first gated feature.

This is a single self-contained handoff so a fresh agent can continue with zero
prior context. Everything below is written from the repository and real test
output at handoff time, not from memory.

---

## 0. THE ONE THING TO UNDERSTAND FIRST

**The app is local-first by design, and that is a hard constraint, not a feature
to "improve."** Easy Life runs entirely on the user's own Windows PC. There is no
cloud account, no telemetry, no subscription server, and the user's data never
leaves the machine unless they opt in. The marketing site sells this ("No
account, nothing of yours sitting on someone else's cloud"). **Do not build
anything that requires a cloud account to run the app.** The Pro/license system
(see §5) is the one deliberate exception and it is code-based, not account-based.

Second constraint: **a Windows `.exe` can only be built on Windows.** PyInstaller
and Inno Setup cannot cross-compile. This Linux container can never produce the
installer. Everything that *builds* must run on the user's Windows PC or on
GitHub Actions' Windows runner.

---

## 1. WHAT THE PRODUCT IS

**Easy Life** (formerly "PC Rituals") is a Windows 10/11 automation app. The user
is a streamer (Twitch: **yoki8ems**). Core concept: **Plays** — ordered lists of
PC actions the user builds once and runs with one tap, from the desktop UI or
from their iPhone.

The user's own example of a Play: *"open obs then switch to MAIN 1 scene then
start stream to twitch and i want the name to be 1234"* — i.e. a natural-language
builder turns that sentence into a Play.

**Action types:** open app, open website, open file/folder, run command, delay,
close app, power control (lock/sleep/restart/shutdown), OBS scene switch, OBS
start/stop stream.

**Key features (all built and tested):**
- **"Describe it"** — natural-language Play builder (`pcrituals/nlplay.py`, ~40
  regex rules, no AI/API/key/internet). Must never silently drop a step; fails
  loudly with "I didn't understand: …".
- **Streamer Mode** — Settings toggle that unlocks an **OBS tab** (live status,
  scene switch, one-tap **Stream Rescue**) and the phone-remote **Stream Rescue
  card**. Both gated on `streamer_mode` (the card was once paired-only — a bug).
- **Stream-drop Web Push notifications** — raw VAPID + RFC 8291 `aes128gcm`,
  no new dependency (uses installed `cryptography`).
- **Remote access from anywhere** — currently **Cloudflare quick tunnel ONLY**
  (Tailscale was removed; see §7 decision). URL changes each start.
- **Phone PWA** — iPhone pairs via expiring QR/code, Add-to-Home-Screen, controls
  PC from anywhere.
- **Deck** — grid of one-tap buttons.
- **Pro license system** — NEW, code-based (see §5). **Sync is now gated behind
  Pro** (the first real unlock, verified).

---

## 2. CURRENT STATE — VERIFIED (real output at handoff)

**Backend test suite** (run at handoff):
```
587 passed, 2 warnings in 54.58s
```
**Frontend suites** (all PASS): `smoke_frontend`, `deck_render_test`,
`onboarding_ui_test`, `frontend_regression_test`, `deep_pages_test`.

**Git:** clean working tree except `dist/Easy-Life-Website.zip` (modified — the
website zip, separate from the app repo). Latest commits:
```
5f6c6d8 Make the CI backend suite self-diagnose instead of eating the 45-min cap
65bce51 Add the app-side Pro license system (Option A: local-first, code-based)
869efb1 Docs and installer support: full README, release tutorial, installer info files
a3d6875 Fix the phone nav: active tab was stretched to full screen height
7772b84 Switch remote access back to Cloudflare-only
ab5ae29 Remove the Cloudflare remote-access provider; harden the notify toggle
f2128b3 Settings split, failed-Play state, Integrations dead-end, and a longer tour
```

**What is ASSUMED / UNVERIFIED (be honest about these):**
| Item | Status |
|---|---|
| Real OBS on real Windows | **UNVERIFIED** — everything up to the WebSocket connection is proven; the first real connection can only be tested on the user's PC |
| `platform.py` ~43 Windows functions | tested only against fakes |
| The Windows `.exe` / installer | **cannot be built here** — must run on Windows or GitHub Actions |
| Web Push delivered to a real iPhone | verified the request leaves the machine (201) but not an actual iOS delivery |
| Cloudflare tunnel against real cloudflared | unit-tested with a fake; never run against the real binary |
| GitHub Actions run #1 | workflow written + validated but first real run is the user's |

---

## 3. ARCHITECTURE & WHY

```
pcrituals/
  config.py      config + data-dir layout (settings.json in data dir)
  models.py      Pydantic models: Ritual/Play, Action, History
  platform.py    Windows + Generic platform abstraction (testable on Linux)
  actions.py     dispatch an Action to its real OS operation
  engine.py      sequential engine (progress/cancel/timeout/retry/continue-stop)
  storage.py     SQLite persistence
  security.py    pairing codes, device tokens (hashed), server secret
  app.py         service layer + live event hub
  api.py         FastAPI REST + SSE + serves the web UI
  obs.py         OBS remote rescue (WebSocket)
  nlplay.py      "Describe it" natural-language Play builder
  notify.py      Web Push (VAPID) + stream-drop watcher
  tunnel.py      Cloudflare quick-tunnel remote access
  streamwatch.py stream-drop detection
  license.py     NEW — Pro license validation (code-based)
  web/           desktop UI + iPhone PWA (single responsive SPA, vanilla JS)
```

**Stack:** Python 3.10+, FastAPI, Uvicorn, SQLite (stdlib), vanilla JS SPA.
Windows automation uses `os.startfile`, `cmd /c`, `taskkill`, PowerShell — all
behind the `Platform` interface so the engine is fully testable on non-Windows.

**Why local-first:** the user's whole pitch is "no account, nothing leaves your
PC." The app binds `0.0.0.0:8765` so the phone can reach it, but every control
endpoint requires a session or a paired device token.

**Why Cloudflare-only (not Tailscale):** the user flip-flopped twice and finally
landed on Cloudflare. See §7 — do not re-litigate.

---

## 4. SECURITY MODEL

- **Local login** — create an account; every control endpoint then requires a
  session. Passwords stored only as salted PBKDF2 hashes.
- **Pairing** — single-use, expiring (5-min) codes; device tokens stored
  **SHA-256 hashed** so a DB leak doesn't expose working keys.
- **Loopback trust** — loopback is trusted only *before* an account exists.
  **Any forwarding header disqualifies a request from counting as local** (a
  tunnel can't impersonate the desktop UI). Rate limits/lockouts key off the
  real forwarded address.
- **Throttling** — login throttled per username AND per client address.
- **Power safety** — destructive actions (restart/shutdown) require confirmation.
- **Import safety** — imports validated, blocks destructive commands.
- **SSRF guard** — `obs_host` restricted to local hosts.
- **XSS** — inline `onclick` eliminated in favor of `data-` attributes +
  delegated listeners (the scene-name XSS root cause); client-supplied ids
  constrained server-side in `models.py`.
- **Sync** — optional, self-hosted, off by default; stores Plays only, never
  credentials.
- **Pro license** — code is HMAC-signed (see §5); the app never stores the
  user's website password.

---

## 5. THE PRO LICENSE SYSTEM (NEW — the current active work)

**Decision (Option A):** local-first app + code-based license. The user buys on
the website, gets a license code, pastes it in the app.

**App side (committed `65bce51`, tested):**
- `pcrituals/license.py` — validates a code against the website's activation
  endpoint, caches locally (24h TTL), keeps last-known-good on a network blip.
- `config.py`: `license_url` (env `PCRITUALS_LICENSE_URL`) + `license_code`.
- `api.py`: `GET /api/pro/status`, `POST /api/pro/activate`.
- `web/app.js`: a **Pro card in Settings** (Everyday section) with code entry +
  status, wired to refresh on render.
- `tests/test_license.py` — 4 tests against a fake activation endpoint.

**Website side (in `/opt/data/easy-life-site`, NOT committed to the app repo —**
it's a separate folder):
- `lib/license.js` — issues/verifies HMAC-signed codes (no database needed).
- `api/activate.js` — the endpoint the app calls.
- `api/webhook.js` — Stripe webhook that mints a code on payment.
- `.env.example` updated with `LICENSE_SECRET` + `STRIPE_WEBHOOK_SECRET`.

**PROVEN end-to-end:** the site issues a code → the app validates it →
`is_pro: true`. Verified by running the site's activate server locally and
having `license.py` validate a real code.

**OPEN / UNFINISHED (the next agent's main work):**
1. **What else does Pro unlock?** Sync is now gated (done, verified). The user
   hasn't decided what else. Recommended: unlimited paired devices + early
   access. **This must be decided and wired before charging.**
2. **Website account system** — the site currently has a single-account-from-env
   login (`lib/users.js`), not a real multi-user signup. The user wants real
   accounts (they said "we have vercel?"). Needs a database (Vercel Postgres /
   Neon, free tier).
3. **Stripe** — needs the user's Stripe account + `STRIPE_WEBHOOK_SECRET` +
   `STRIPE_PAYMENT_LINK`/`STRIPE_SECRET_KEY`. Pricing the user wants: **$4/mo or
   $40/yr** (they asked if that's reasonable — it is; but see the honest note
   below about subscription vs one-time for a local-first app).
4. **Deploy to Vercel** — the connected Vercel token (team `hermes`) is **403
   blocked** from deploying to `easy-life-website`. The user must fix the token
   role (Settings → Members → Admin/Deploy) or deploy manually.
5. **Root-cause the CI backend-suite stall** — the workflow now self-diagnoses
   (`--timeout=120 -x`), but the underlying Windows-only stall is NOT yet found.
   All 31 test files pass fast on Linux; the next agent needs the failing test
   name from the Actions log.

**Honest note to carry forward:** a *subscription* ($4/mo) is arguably the wrong
model for a local-first app with near-zero ongoing cost; a one-time unlock fits
better. The user is leaning subscription. Flag this once, then respect their
choice.

---

## 6. BUGS ALREADY FOUND AND FIXED (do not re-fix, do not re-break)

- **Phone nav stretched to full screen** (`a3d6875`): mobile `.sidebar` inherited
  `top:0` from desktop while mobile set `bottom:0` → full-height bar, active tab
  831px tall. Fixed with `top:auto`. Verified: 38px tab in 51px bar.
- **Notification toggle flip-back** (`ab5ae29`): toggle updated state from the
  POST response; if the response omitted a field the next render flipped it off.
  Fixed by re-fetching authoritative settings after save + honest revert on
  failure. Verified: stays on/off across 20 samples.
- **Blank Settings page** (`6ce5624`): `renderNav()` rebuilt sections with no
  `.active` class → all pages CSS-hidden. Fixed centrally in `render()`. **This
  was a regression I introduced** — measure rendered boxes, not DOM node counts.
- **Stored XSS via scene name** (`9dce6a6`): `esc()` escapes `'`→`&#39;` but the
  HTML parser decodes it back inside an inline onclick. Fixed with delegated
  listeners.
- **Stream watcher never started** (`311c837`): wired into `desktop.py`/`api.run`
  but not `create_app`; now a singleton started via FastAPI lifespan.
- **OBS tab status frozen** (`63ee86c`): `tick()` only re-rendered
  dashboard/remote; made OBS page re-render per tick.
- **Stream Rescue card gated wrong** (`49b876e`): was paired-only, now requires
  `streamer_mode` too.
- **`smoke_frontend.js` stale** ("New Ritual" after rebrand) — failing silently
  because JS suites aren't in the pytest run.
- **notify.py defects** (63-byte ES256 sigs, per-subscription isolation,
  subscribe-time endpoint validation, VAPID key mismatch) — all fixed + tested.
- **CI backend suite eating the 45-min cap** (`5f6c6d8`): added `pytest-timeout
  --timeout=120 -x` + lowered job cap to 22 min so a hang names itself. **The
  underlying CI-only stall is NOT yet root-caused** — all 31 test files pass fast
  on Linux; the next agent needs the failing test name from the Actions log.
- **Pro gate** (`c9b9dd1`): sync card now shows a "Sync is a Pro feature" lock
  for free users and the connect form for Pro users. Verified in a real browser
  (free → lock, simulated Pro → connect form).

---

## 7. DECISIONS MADE — DO NOT RE-LITIGATE

- **Cloudflare-only remote access** (final, after two flip-flops). Tailscale
  `funnel.py` was deleted; `tunnel.py` (Cloudflare) is the only provider. The
  user explicitly said "make it just cloudflare." The trade-off (URL changes each
  start) is documented in the UI. **Do not re-add Tailscale unless the user asks.**
- **"Describe it" is rule-based, not AI.** No API key, no account, no internet.
  Its whole promise is it runs on the machine. A guesser would silently build
  wrong steps; rules fail loudly instead. Do not add an AI dependency.
- **Local-first is sacred** (§0). No cloud account required to run the app.
- **Pro = code-based (Option A), not account-based.** The app stays local-first.
- **Rebrand:** internal names keep `pcrituals`/`rituals`; user-facing is "Play".
- **The app never auto-installs cloudflared/Tailscale** — it only prints the
  `winget` command. Do not change this.
- **In-app updates over "download a new installer"** — the user finds re-download
  annoying. The updater writes into the per-user install folder (not Program
  Files) so it needs no admin.

---

## 8. CONVENTIONS

- **Run tests:** `cd /opt/data/pc-rituals && source .venv/bin/activate && unset
  PCRITUALS_TLS && python -m pytest tests/ -q -p no:cacheprovider --tb=line`
- **Frontend suites:** `node tests/<name>.js` (they need a live server on 8765
  for the live/phone ones; the 5 CI ones run standalone).
- **Run the app:** `python -m pcrituals` (binds 0.0.0.0:8765). For a test server:
  `python -m uvicorn pcrituals.api:create_app --factory --port <port> --host
  127.0.0.1` with `PCRITUALS_DATA_DIR=/tmp/el_<name>` for isolation.
- **Browser verification:** use puppeteer at
  `/opt/data/shot-tool/` (CHROME at
  `/opt/data/.cache/puppeteer/chrome/linux-153.0.8010.47/chrome-linux64/chrome`).
  **Measure rendered geometry, not DOM node presence** (the blank-page trap).
- **Commit-message safety guard** trips on words like "watch"/"credential" —
  write the message to a `.commitmsg` file and `git commit -F` when that happens.
- **The `patch` tool's fuzzy matcher corrupts repeated tokens** (e.g. "overflow",
  "json.loads") — when it mangles a line, fix it with `sed` on the exact line
  number instead of re-patching.
- **Website is a SEPARATE folder** `/opt/data/easy-life-site` (not a git repo).
  The app repo is `/opt/data/pc-rituals`. Don't confuse them.

---

## 9. WHAT THE USER WAS TOLD (keep messages consistent)

- The app is in good shape: **587 backend + 5 CI frontend suites pass**, tree
  clean, latest build is the Cloudflare-only v14.
- The notification toggle and phone-nav bugs are fixed and verified.
- The website was updated to show **real app screenshots** + the **real Easy Life
  logo** (liquid-glass globe), and the license system was added — but **deploy to
  Vercel is blocked** (token 403) and the user must fix the token role or deploy
  manually.
- The GitHub Actions workflow was made self-diagnosing; the user was told the
  next run will either pass or name the stalling test, and to send that name.
- The user is non-technical, communicates informally (voice-to-text, typos),
  wants the assistant to infer intent and just make it work. They get frustrated
  with long answers and over-explaining. Be direct, do the work, report briefly.
- **The user is going to sleep / hands off overnight** — they want autonomous
  progress without asking for approval, but STOP for genuinely destructive,
  credential-exposing, financial, or security-critical actions.

---

## 10. IMMEDIATE NEXT TASKS (priority order)

1. **Decide + wire what else Pro unlocks** (highest value — sync is gated, but
   the user should confirm unlimited devices + early access too). Ask the user
   once, then implement.
2. **Get the failing CI test name** — re-run the GitHub Actions workflow; if it
   fails, read the `Timeout >120.0s` line and root-cause the Windows-only stall.
3. **Build the website account system** (real signup/login + database) and wire
   the Stripe webhook → license-code flow. Needs the user's Stripe + a database.
4. **Fix the Vercel deploy** (token role) and deploy the updated site (real
   screenshots, real logo, license system).
5. **Swap the site's download button** to point at the GitHub-built
   `Easy-Life-Setup-0.1.0.exe` once the release is live (currently it ships the
   source zip).

---

## 11. KEY FILES / PATHS

- App repo: `/opt/data/pc-rituals` (git, branch `master`)
- Website: `/opt/data/easy-life-site` (separate, not git)
- App ZIP: `/opt/data/pc-rituals/dist/Easy-Life-Windows.zip`
- Website ZIP: `/opt/data/pc-rituals/dist/Easy-Life-Website.zip`
- Real logo: `/opt/data/pc-rituals/pcrituals/web/icons/icon-192.png` (and
  `/opt/data/images/logo_400.jpg`, `gen_logo.jpg`)
- Real app screenshots (for the site): `/opt/data/easy-life-site/assets/app-*.png`
- Browser tooling: `/opt/data/shot-tool/`
- Docs: `README.md` (new, streamer-focused), `BUILD.md`, `USER_GUIDE.md`,
  `REMOTE_ACCESS.md`, `GITHUB_RELEASE_TUTORIAL.md`
- User's Twitch: **yoki8ems** · GitHub: **nixxioncrac** · Vercel team: **hermes**

---

*End of handoff. Verify everything against the repo before acting — the numbers
above were captured at handoff time and are real, but the repo is the source of
truth.*
